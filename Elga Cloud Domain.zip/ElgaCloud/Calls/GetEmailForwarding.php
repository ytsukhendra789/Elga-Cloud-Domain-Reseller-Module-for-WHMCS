<?php
namespace ModulesGarden\DomainsReseller\Registrar\ElgaCloud\Calls;
use ModulesGarden\DomainsReseller\Registrar\ElgaCloud\Core\Call;

/**
 * Description of GetEmailForwarding
 *
 * @author inbs
 */
class GetEmailForwarding extends Call
{
    public $action = "domains/:domain/email";
    
    public $type = parent::TYPE_GET;
}