<?php
namespace ModulesGarden\DomainsReseller\Registrar\ElgaCloud\Calls;
use ModulesGarden\DomainsReseller\Registrar\ElgaCloud\Core\Call;

/**
 * Description of GetDns
 *
 * @author inbs
 */
class GetDns extends Call
{
    public $action = "domains/:domain/dns";
    
    public $type = parent::TYPE_GET;
}