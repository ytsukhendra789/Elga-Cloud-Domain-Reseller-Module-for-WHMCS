<?php
namespace ModulesGarden\DomainsReseller\Registrar\ElgaCloud\Calls;
use ModulesGarden\DomainsReseller\Registrar\ElgaCloud\Core\Call;

/**
 * Description of GetNameServers
 *
 * @author inbs
 */
class Sync extends Call
{
    public $action = "domains/:domain/sync";
    
    public $type = parent::TYPE_POST;
}