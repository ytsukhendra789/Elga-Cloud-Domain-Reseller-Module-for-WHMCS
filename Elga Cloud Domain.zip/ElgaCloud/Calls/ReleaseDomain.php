<?php
namespace ModulesGarden\DomainsReseller\Registrar\ElgaCloud\Calls;
use ModulesGarden\DomainsReseller\Registrar\ElgaCloud\Core\Call;

/**
 * Description of TransferDomain
 *
 * @author inbs
 */
class ReleaseDomain extends Call
{
    public $action = "domains/:domain/release";
    
    public $type = parent::TYPE_POST;
}